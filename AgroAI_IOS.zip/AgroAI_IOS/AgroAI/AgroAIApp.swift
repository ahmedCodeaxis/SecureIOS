//
//  AgroAIApp.swift
//  AgroAI
//
//  Created by Apple Esprit on 5/11/2024.
//

import SwiftUI

@main
struct AgroAIApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            Splashscreen()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
