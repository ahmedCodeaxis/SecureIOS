import SwiftUI

struct ChangePassUIView: View {
    @StateObject var viewModel = ChangePassViewModel()
    @ObservedObject var navigationManager: NavigationStateManager
 
    
    
    

    
    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                HStack {
                    Button(action: {
                        navigationManager.currentScreen = .profile
                    }) {
                        Image(systemName: "arrow.left")
                            .font(.system(size: 24))
                            .foregroundColor(Color.white)
                    }
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 20)
                
                Spacer()
                
                Text("Change Password")
                    .font(Font.system(size: 30).weight(.bold))
                    .foregroundColor(Color.white)
                
                Spacer()
                
                // Current Password Field
                passwordField(label: "Current Password", password: $viewModel.currentPassword, isVisible: $viewModel.isCurrentPasswordVisible)
                
                // New Password Field
                passwordField(label: "New Password", password: $viewModel.newPassword, isVisible: $viewModel.isNewPasswordVisible)
                
                // Confirm Password Field
                passwordField(label: "Confirm Password", password: $viewModel.confirmPassword, isVisible: $viewModel.isConfirmPasswordVisible)
                
                // Error Message (if any)
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.system(size: 14))
                        .padding(.top, 10)
                }

                // Change Password Button
                Button(action: {
                    Task {
                        await viewModel.updatePassword()
                    }
                }) {
                    Text("Change Password")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color.white)
                        .frame(width: 315, height: 52)
                        .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.5)
                                .stroke(Color.white, lineWidth: 1.50)
                        )
                }
                .padding(.top, 30)
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
        .onAppear {
            viewModel.loadUserData()
        }
    }
    
    private func passwordField(label: String, password: Binding<String>, isVisible: Binding<Bool>) -> some View {
        VStack(alignment: .leading) {
            Text(label)
                .foregroundColor(Color.white)
                .bold()
            
            HStack {
                Image(systemName: "lock.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .padding(.horizontal, 15)
                
                if isVisible.wrappedValue {
                    TextField(label, text: password)
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color.black)
                } else {
                    SecureField(label, text: password)
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color.black)
                }
                
                Button(action: {
                    isVisible.wrappedValue.toggle()
                }) {
                    Image(systemName: isVisible.wrappedValue ? "eye.fill" : "eye.slash.fill")
                        .foregroundColor(.gray)
                }
                .padding(.trailing, 15)
            }
            .padding()
            .background(Color.white.opacity(0.2))
            .cornerRadius(8)
        }
        .frame(width: 315)
    }
}



struct ChangePassUIView_Previews : PreviewProvider {
     static var previews : some View {
         ChangePassUIView(navigationManager:
          NavigationStateManager())
     }
}
