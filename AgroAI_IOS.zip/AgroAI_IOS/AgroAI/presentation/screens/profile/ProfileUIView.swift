import SwiftUI
import JWTDecode
import SwiftKeychainWrapper // Import KeychainWrapper

struct ProfileUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @State private var userName: String = "Loading..."
    @State private var userEmail: String = "Loading..."
    
    // State for showing the EditProfile view
    @State private var EditProfile = false  // Control state for showing the Profile view
    @State private var ChangePaswword = false  // Control state for showing the Profile view

    var body: some View {
        // Wrap the entire content of ProfileUIView in a NavigationView
        NavigationView {
            ZStack {
                Color(red: 0.29, green: 0.68, blue: 0.47)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 20) {
                    // Profile Header
                    HStack {
                        Spacer()
                        Button(action: {
                            // Add logout action
                            navigationManager.logout()
                            print("pressed")
                            print("logout")
                        }) {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                                .font(.system(size: 24))
                                .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 50)
                    
                    // Profile Image
                    Image("profile_placeholder") // Add a profile image asset
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                        .overlay(
                            Circle()
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 2)
                        )
                        .padding(.top, 20)
                    
                    // User Name and Email
                    Text(userName)
                        .font(Font.custom("Poppins", size: 24).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    Text(userEmail)
                        .font(Font.custom("Poppins", size: 16).weight(.medium))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .padding(.bottom, 30)
                    
                    // Profile Options
                    VStack(spacing: 15) {
                        Button(action: {
                            // Set the state to true to show the fullScreenCover
                            EditProfile = true
                            print("Edit Profile tapped") // Debugging
                        }) {
                            ProfileOptionButton(icon: "person.fill", text: "Edit Profile")
                        }
                        
                        
                        Button(action: {
                            // Set the state to true to show the fullScreenCover
                            ChangePaswword = true
                            print("Edit Profile tapped") // Debugging
                        }) {
                            ProfileOptionButton(icon: "lock.fill", text: "Change Password")
                        }
                        
                        
                                                
                        
                        
                        
                        
                        ProfileOptionButton(icon: "bell.fill", text: "Notifications")
                        ProfileOptionButton(icon: "questionmark.circle.fill", text: "Help & Support")
                        ProfileOptionButton(icon: "doc.text.fill", text: "Terms & Privacy Policy")
                    }
                    .padding(.horizontal, 20)
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                // Show the EditProfile view when state is true
                .fullScreenCover(isPresented: $EditProfile) {
                    // Ensure you're passing the correct navigationManager
                    EditProfileUIView(navigationManager: navigationManager)
                }
                
                .fullScreenCover(isPresented: $ChangePaswword) {
                    // Ensure you're passing the correct navigationManager
                    ChangePassUIView(navigationManager: navigationManager)

                }
                
                
                
                
            }
            .navigationTitle("Profile") // Navigation bar title for the Profile screen
            .onAppear {
                // Retrieve token from Keychain on appear
                if let token = KeychainWrapper.standard.string(forKey: "authToken") {
                    print (token)
                    decodeToken(token: token)
                } else {
                    print("No token found in Keychain.")
                    // Handle case where token is not found (e.g., navigate to login)
                }
            }
        }
        // Ensure the entire ProfileUIView is wrapped in a NavigationView
    }

    private func addBase64Padding(to string: String) -> String {
        let length = string.count
        let paddedLength = length + (4 - length % 4) % 4
        let padding = String(repeating: "=", count: paddedLength - length)
        return string + padding
    }

    // Modified decodeToken to accept the token as a parameter
    private func decodeToken(token: String) {
        // Split the token into its components
        let components = token.components(separatedBy: ".")
        guard components.count > 1 else {
            print("Invalid token format")
            return
        }
        // Get the claims part (middle part) of the token
        let claimsPart = components[1]
        // Ensure correct base64 padding
        let paddedClaimsPart = addBase64Padding(to: claimsPart)
        // Replace URL-safe Base64 characters
        let base64EncodedString = paddedClaimsPart.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        // Decode base64 string
        guard let data = Data(base64Encoded: base64EncodedString) else {
            print("Failed to decode base64")
            return
        }
        // Parse JSON
        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                // Extract user information
                DispatchQueue.main.async {
                    self.userName = json["name"] as? String ?? "No Name"
                    self.userEmail = json["email"] as? String ?? "No Email"
                }
            } else {
                print("Failed to parse JSON")
            }
        } catch {
            print("Failed to parse JSON: \(error)")
        }
    }
}

struct ProfileOptionButton: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .font(.system(size: 20))
                .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                .frame(width: 30)
            Text(text)
                .font(Font.custom("Poppins", size: 16).weight(.medium))
                .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
            Spacer()
            Image(systemName: "chevron.right")
                .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
        }
        .padding()
        .background(Color(red: 0.84, green: 0.89, blue: 0.89))
        .cornerRadius(8)
    }
}

struct ProfileUIView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileUIView(navigationManager: NavigationStateManager())
    }
}
