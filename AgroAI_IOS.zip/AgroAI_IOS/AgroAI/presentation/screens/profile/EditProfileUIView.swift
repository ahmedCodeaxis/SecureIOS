import SwiftUI
struct EditProfileUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @StateObject private var viewModel = EditProfileViewModel()

    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)

            VStack(spacing: 20) {
                headerView
                
                Text("Edit Profile")
                    .font(.system(size: 30).weight(.bold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))

                profileImageView
                
                formFields
                
                saveButton
                
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.system(size: 14))
                        .padding(.top, 10)
                }
                
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 40)
            .onAppear {
                viewModel.loadUserData()
            }
        }
        .fullScreenCover(isPresented: $viewModel.showProfile) {
            ProfileUIView(navigationManager: navigationManager)
                .onDisappear {
                    navigationManager.currentScreen = .profile
                }
        }
    }

    private var headerView : some View {
       HStack{
           Button(action:{
               navigationManager.currentScreen = .profile
           }){
               Image(systemName:"arrow.left")
                   .font(.system(size :24))
                   .foregroundColor(Color(red :0.93 ,green :    0.93 ,blue :    0.93))
           }
           Spacer()
       }.padding(.horizontal ,20).padding(.top ,20)
   }

   private var profileImageView : some View{
       Button(action:{
           // Implement image picker functionality here if needed.
       }){
           Image("profile_placeholder")
               .resizable()
               .scaledToFit()
               .frame(width :120 ,height :120 )
               .clipShape(Circle())
               .overlay(
                   Circle()
                       .stroke(Color(red :0.93 ,green :    0.93 ,blue :    0.93), lineWidth :2)
               )
       }.padding(.top ,20)
   }

   private var formFields : some View{
       VStack(spacing :20){
           field(title : "Full Name", placeholder : "Full Name", textBinding : $viewModel.fullName, imageName : "person.fill")
           field(title : "Email", placeholder : "Email", textBinding : $viewModel.email, imageName : "envelope.fill")
       }.padding(.horizontal ,20)
   }

   private func field(title : String ,placeholder : String ,textBinding : Binding<String> ,imageName : String) -> some View{
       VStack(alignment:.leading){
           Text(title)
               .foregroundColor(Color(red :0.93 ,green :    0.93 ,blue :    0.93))
               .bold()

           HStack(spacing :0){
               Image(systemName:imageName)
                   .resizable()
                   .scaledToFit()
                   .frame(width :20 ,height :20 )
                   .foregroundColor(.gray)
                   .padding(.horizontal ,15)

               TextField(placeholder ,text:textBinding )
                   .font(Font.custom("Poppins", size :14).weight(.medium))
                   .foregroundColor(Color(red :0.23 ,green :    0.25 ,blue :    0.28))
                   .padding()
           }.background(Color(red :0.84 ,green :    0.89 ,blue :    0.89))
           .cornerRadius(8)
       }
   }

   private var saveButton : some View{
       Button(action:{
           Task{
               await viewModel.updateProfile()
           }
       }){
           Text("Save Changes")
               .font(.system(size :18).weight(.bold))
               .foregroundColor(.green)
               .frame(width :250,height :50)
               .background(Color(red :0.84 ,green :    0.89 ,blue :    0.89))
               .cornerRadius(25)
               .padding(.top ,20)
       }
   }
}

struct EditProfileUIView_Previews : PreviewProvider {
     static var previews : some View {
         EditProfileUIView(navigationManager:
          NavigationStateManager())
     }
}
