import SwiftUI

struct SignInUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @StateObject private var viewModel = SignInViewModel()
    
    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                Image("image")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 100, height: 100)
                    .padding(.top, 50)
                
                Text("Sign in")
                    .font(Font.custom("Poppins", size: 24).weight(.semibold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .padding(.bottom, 20)
                
                // Email Field
                customTextField(title: "Email", placeholder: "Email", text: $viewModel.email, imageName: "ic_email")
                
                // Password Field
                customSecureField(title: "Password", placeholder: "Password", text: $viewModel.password, imageName: "ic_password")
                
                // Forgot Password Button
                forgotPasswordButton
                
                // Sign In Button
                signInButton
                
                if let errorMessage = viewModel.errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                }
                
                // Register Button
                registerButton
                
                Spacer()
            }
            .padding(.horizontal, 20)
            .overlay(
                Group {
                    if viewModel.isLoading {
                        ProgressView("Signing in...")
                            .progressViewStyle(CircularProgressViewStyle())
                            .padding()
                    }
                }
            )
        }
        // Navigate to ProfileUIView when showProfile is true
        .fullScreenCover(isPresented: $viewModel.showProfile) {
            ProfileUIView(navigationManager: navigationManager)
        }
        // Fullscreen cover to present ForgotPasswordUIView if needed
        .fullScreenCover(isPresented: .constant(navigationManager.currentScreen == .forgotPassword)) {
            ForgetPassUIView(navigationManager: navigationManager)
        }
    }
    
    // Custom TextField for Email
    private func customTextField(title: String, placeholder: String, text: Binding<String>, imageName: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                .bold()
            
            HStack(spacing: 0) {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .padding(.horizontal, 15)
                
                TextField(placeholder, text: text)
                    .font(Font.custom("Poppins", size: 14).weight(.medium))
                    .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                    .padding()
            }
            .background(Color(red: 0.84, green: 0.89, blue: 0.89))
            .cornerRadius(8)
        }
        .frame(width: 315)
    }
    
    // Custom SecureField for Password
    private func customSecureField(title: String, placeholder: String, text: Binding<String>, imageName: String) -> some View {
        VStack(alignment:.leading ,spacing :8 ) {
            Text(title)
                .foregroundColor(Color(red :0.93 ,green :    0.93 ,blue :    0.93))
                .bold()
            
            HStack(spacing: 0) {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .padding(.horizontal, 15)
                
                SecureField(placeholder, text:text)
                    .font(Font.custom("Poppins", size :14).weight(.medium))
                    .foregroundColor(Color(red :0.23 ,green :    0.25 ,blue :    0.28))
                    .padding()
            }
            .background(Color(red :0.84 ,green :    0.89 ,blue :    0.89))
            .cornerRadius(8)
        }
        .frame(width :315)
    }
    
    // Forgot Password Button
    private var forgotPasswordButton : some View {
        HStack {
            Spacer()
            Button(action : {
                navigationManager.currentScreen = .forgotPassword
            }) {
                Text("Forgot Password?")
                    .font(Font.custom("Poppins", size :14).weight(.medium))
                    .foregroundColor(Color(red :0.93 ,green :    0.93 ,blue :    0.93))
            }
        }
        .frame(width :315)
        .padding(.top ,-10)
    }
    
    // Sign In Button
    private var signInButton: some View {
        Button(action: {
            Task {
                await viewModel.signIn()
            }
        }) {
            Text("Sign in")
                .font(Font.custom("Poppins", size: 18).weight(.semibold))
                .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                .frame(width: 315, height: 52)
                .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .inset(by: 1.50)
                        .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.50)
                )
        }
    }
    
    // Register Button
    private var registerButton: some View {
        Button(action: {
            navigationManager.currentScreen = .signUp
        }) {
            Text("Register")
                .font(Font.custom("Poppins", size: 18).weight(.semibold))
                .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
        }
        .padding(.top, 10)
    }
}
struct SignInUIView_Previews : PreviewProvider {

   static var previews : some View {

       SignInUIView(navigationManager :
       NavigationStateManager())

   }

}
