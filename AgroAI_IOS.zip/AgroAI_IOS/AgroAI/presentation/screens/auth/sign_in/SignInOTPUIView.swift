import SwiftUI

struct SignInOTPUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @State private var otpFields: [String] = Array(repeating: "", count: 4)
    
    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // Logo
                Image("ic_email_submit_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 170, height: 157)
                    .padding(.top, 50)
                
                // Title
                Text("2-Step Verification")
                    .font(Font.custom("Poppins", size: 32).weight(.semibold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                Text("Enter the verification code we just sent to your email")
                    .font(Font.custom("Poppins", size: 16).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                
                // OTP Fields
                HStack(spacing: 20) {
                    ForEach(0..<4) { index in
                        TextField("", text: $otpFields[index])
                            .font(.system(size: 24, weight: .bold))
                            .frame(width: 60, height: 60)
                            .background(Color(red: 0.84, green: 0.89, blue: 0.89))
                            .cornerRadius(12)
                            .multilineTextAlignment(.center)
                            .keyboardType(.numberPad)
                            .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 2)
                            )
                            .onChange(of: otpFields[index]) { newValue in
                                if newValue.count > 1 {
                                    otpFields[index] = String(newValue.prefix(1))
                                }
                                if newValue.count == 1 && index < 3 {
                                    // Move to next field
                                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                                    }
                                }
                            }
                    }
                }
                .padding(.vertical, 30)
                
                // Timer Text
                Text("Code expires in: 03:00")
                    .font(Font.custom("Poppins", size: 14).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                // Resend Code
                Button(action: {
                    print("Resend code tapped")
                }) {
                    Text("Resend Code")
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .underline()
                }
                .padding(.top, 10)
                
                // Verify Button
                Button(action: {
                    print("Verify button tapped")
                }) {
                    Text("Verify")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .frame(width: 315, height: 52)
                        .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.50)
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.50)
                        )
                }
                .padding(.top, 30)
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
    }
}

struct SignInOTPUIView_Previews: PreviewProvider {
    static var previews: some View {
        SignInOTPUIView(navigationManager: NavigationStateManager())
    }
}
