import SwiftUI

// Define the request struct that we'll send to the backend
struct ResetPasswordRequest: Codable {
    let email: String
    let otpCode: String
    let newPassword: String
}

struct ResetPassUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var isPasswordVisible: Bool = false
    @State private var isConfirmPasswordVisible: Bool = false
    @State private var errorMessage: String? = nil
    @State private var isButtonDisabled: Bool = false // To disable button during network request
    @State private var email: String // Assuming you are passing the user's email here
    @State private var otpCode: String // OTP code for password reset (you can pass it from another screen)
    
    // Default initializer
    init(navigationManager: NavigationStateManager, email: String = "test@example.com", otpCode: String = "123456") {
        self.navigationManager = navigationManager
        self._email = State(initialValue: email)
        self._otpCode = State(initialValue: otpCode)
    }
    
    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // Logo
                Image("ic_email_submit_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 170, height: 157)
                    .padding(.top, 50)
                
                // Title
                Text("Reset Password")
                    .font(Font.custom("Poppins", size: 32).weight(.semibold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                Text("Create your new password")
                    .font(Font.custom("Poppins", size: 16).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .multilineTextAlignment(.center)
                    .padding(.bottom, 20)
                
                // New Password Field
                passwordField("New Password", isVisible: $isPasswordVisible, password: $newPassword)
                
                // Confirm Password Field
                passwordField("Confirm Password", isVisible: $isConfirmPasswordVisible, password: $confirmPassword)
                
                // Error message (if any)
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .font(.system(size: 14))
                        .foregroundColor(.red)
                        .padding(.top, 10)
                }

                // Continue Button
                Button(action: {
                    if validatePasswords() {
                        isButtonDisabled = true // Disable button during API call
                        resetPassword(email: email, otpCode: otpCode, newPassword: newPassword) { success, error in
                            isButtonDisabled = false // Re-enable button after request
                            if success {
                                navigationManager.currentScreen = .signIn
                            } else {
                                errorMessage = error ?? "An unknown error occurred."
                            }
                        }
                    }
                }) {
                    Text("Continue")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .frame(width: 315, height: 52)
                        .background(isButtonDisabled ? Color.gray : Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.50)
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.50)
                        )
                        .opacity(isButtonDisabled ? 0.5 : 1.0) // Adjust opacity when disabled
                }
                .padding(.top, 30)
                .disabled(isButtonDisabled) // Disable the button to prevent multiple taps
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
    }
    
    private func passwordField(_ label: String, isVisible: Binding<Bool>, password: Binding<String>) -> some View {
        VStack(alignment: .leading) {
            Text(label)
                .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                .bold()
            
            HStack {
                Image("ic_password")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                    .padding(.horizontal, 15)
                
                if isVisible.wrappedValue {
                    TextField(label, text: password)
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                        .autocapitalization(.none) // Disable autocapitalization for passwords
                        .disableAutocorrection(true) // Disable autocorrection
                } else {
                    SecureField(label, text: password)
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                        .autocapitalization(.none) // Disable autocapitalization for passwords
                        .disableAutocorrection(true) // Disable autocorrection
                }
                
                Button(action: {
                    isVisible.wrappedValue.toggle()
                }) {
                    Image(systemName: isVisible.wrappedValue ? "eye.fill" : "eye.slash.fill")
                        .foregroundColor(.gray)
                }
                .padding(.trailing, 15)
            }
            .padding()
            .background(Color(red: 0.84, green: 0.89, blue: 0.89))
            .cornerRadius(8)
        }
        .frame(width: 315)
    }

    private func validatePasswords() -> Bool {
        if newPassword.isEmpty || confirmPassword.isEmpty {
            errorMessage = "Please fill in both password fields."
            return false
        }
        
        if newPassword != confirmPassword {
            errorMessage = "Passwords do not match. Please try again."
            return false
        }

        if newPassword.count < 8 {
            errorMessage = "Password must be at least 8 characters."
            return false
        }
        
        errorMessage = nil
        return true
    }

    // Networking function to reset the password
    private func resetPassword(email: String, otpCode: String, newPassword: String, completion: @escaping (Bool, String?) -> Void) {
        let url = URL(string: "https://your-api-endpoint.com/auth/reset-password")! // Replace with your actual API endpoint
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Construct the request body
        let body = ResetPasswordRequest(email: email, otpCode: otpCode, newPassword: newPassword)
        
        do {
            let encoder = JSONEncoder()
            request.httpBody = try encoder.encode(body)
        } catch {
            completion(false, "Failed to encode request body.")
            return
        }
        
        // Send the network request
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    completion(false, error.localizedDescription)
                }
                return
            }
            
            guard let data = data else {
                DispatchQueue.main.async {
                    completion(false, "No data received.")
                }
                return
            }
            
            // Handle the response
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                DispatchQueue.main.async {
                    completion(true, nil)
                }
            } else {
                DispatchQueue.main.async {
                    completion(false, "Failed to reset password.")
                }
            }
        }.resume()
    }
}

struct ResetPassUIView_Previews: PreviewProvider {
    static var previews: some View {
        // Now we provide default email and otpCode in the preview initializer
        ResetPassUIView(navigationManager: NavigationStateManager(), email: "test@example.com", otpCode: "123456")
    }
}
