import SwiftUI

struct ForgetPassOTPUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @State private var otpFields: [String] = Array(repeating: "", count: 4) // 4 OTP fields
    @State private var otpCode: String = "" // Combined OTP code to verify
    @State private var errorMessage: String? = nil // Error message for invalid OTP
    @State private var isVerified = false // Flag to track verification status
    @State private var timer: Timer? = nil // Timer to handle resend code functionality
    @State private var timeRemaining: Int = 60 // Timer countdown (in seconds)
    @State private var isResendEnabled = true // Flag to control resend button state
    
    // Focus state to manage which OTP field is focused
    @FocusState private var focusedField: Int?
    
    // Base URL for the API
    let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"
    // Email passed from the previous screen
    var email: String
    
    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // Logo
                Image("ic_email_submit_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 170, height: 157)
                    .padding(.top, 50)
                
                // Title
                Text("OTP Verification")
                    .font(Font.custom("Poppins", size: 32).weight(.semibold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                Text("Enter the verification code we just sent to your email address")
                    .font(Font.custom("Poppins", size: 16).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                
                // OTP Fields
                HStack(spacing: 15) {
                    ForEach(0..<4) { index in
                        TextField("", text: $otpFields[index])
                            .frame(width: 50, height: 50)
                            .background(Color(red: 0.84, green: 0.89, blue: 0.89))
                            .cornerRadius(8)
                            .multilineTextAlignment(.center)
                            .keyboardType(.numberPad)
                            .focused($focusedField, equals: index)
                            .onChange(of: otpFields[index]) { newValue in
                                if newValue.count > 1 {
                                    otpFields[index] = String(newValue.prefix(1)) // Allow only 1 character
                                }
                                if newValue.count == 1, index < 3 {
                                    focusedField = index + 1
                                }
                                if newValue.isEmpty, index > 0 {
                                    focusedField = index - 1
                                }
                            }
                    }
                }
                .padding(.vertical, 20)
                
                // Timer for "Resend Code" text
                Text("Resend OTP in \(timeRemaining) seconds")
                    .font(Font.custom("Poppins", size: 14).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .padding(.top, 10)
                
                // Resend Code Button
                Button(action: resendCode) {
                    Text("Resend Code")
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .underline()
                        .disabled(!isResendEnabled)
                }
                .padding(.top, 10)
                
                // Verify Button
                Button(action: verifyOTP) {
                    Text("Verify")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .frame(width: 315, height: 52)
                        .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.50)
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.50)
                        )
                }
                .padding(.top, 20)
                
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .font(.system(size: 14))
                        .foregroundColor(.red)
                        .padding(.top, 10)
                }
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
        .onAppear {
            startTimer()
        }
        .onDisappear {
            timer?.invalidate()
        }
    }
    
    private func startTimer() {
        timeRemaining = 60
        isResendEnabled = false
        
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
            } else {
                isResendEnabled = true
                timer?.invalidate()
            }
        }
    }
    
    private func resendCode() {
        startTimer()  // Restart the timer
    }
    
    private func verifyOTP() {
        otpCode = otpFields.joined()
        
        guard !otpCode.isEmpty else {
            errorMessage = "Please enter the OTP code."
            return
        }
        
        verifyOTPOnServer()
    }
    
    private func verifyOTPOnServer() {
        guard let url = URL(string: "\(baseURL)/user/verify-otp") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let parameters: [String: Any] = [
            "email": email,
            "otpCode": otpCode
        ]
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])
            request.httpBody = jsonData
        } catch {
            print("Error serializing JSON: \(error)")
            return
        }
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.errorMessage = "Error: \(error.localizedDescription)"
                }
                return
            }
            
            if let data = data, let responseString = String(data: data, encoding: .utf8) {
                DispatchQueue.main.async {
                    if responseString.contains("success") {
                        self.isVerified = true
                        self.errorMessage = nil
                    } else {
                        self.errorMessage = "Invalid OTP. Please try again."
                    }
                }
            }
        }
        
        task.resume()
    }
}

struct ForgetPassOTPUIView_Previews: PreviewProvider {
    static var previews: some View {
        ForgetPassOTPUIView(navigationManager: NavigationStateManager(), email: "test@example.com")
    }
}
