import SwiftUI

struct ForgetPassUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @State private var email: String = ""
    @State private var isLoading = false
    @State private var errorMessage: String?
    
    let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"

    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // Logo Image
                Image("ic_email_submit_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 170, height: 157)
                    .padding(.top, 50)
                
                // Title
                Text("Forgot Password?")
                    .font(Font.custom("Poppins", size: 32).weight(.semibold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                Text("Enter your email for the verification process, we will send a code to your email")
                    .font(Font.custom("Poppins", size: 16).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                
                // Email Field
                VStack(alignment: .leading) {
                    Text("Email")
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    
                    HStack {
                        Image("ic_email") // Assuming you have an icon named "ic_email"
                            .resizable()
                            .scaledToFit()
                            .frame(width: 20, height: 20)
                            .padding(.horizontal, 15)
                        
                        TextField("Enter your email", text: $email)
                            .font(Font.custom("Poppins", size: 14).weight(.medium))
                            .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                            .padding()
                            .autocapitalization(.none)
                            .keyboardType(.emailAddress)
                    }
                    .background(Color(red: 0.84, green: 0.89, blue: 0.89))
                    .cornerRadius(8)
                }
                .frame(width: 315)
                .padding(.bottom, 20)
                
                // Error Message
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.caption)
                        .padding()
                }
                
                // Continue Button
                Button(action: {
                    sendPasswordResetCode()
                }) {
                    if isLoading {
                        ProgressView()
                            .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            .frame(width: 315, height: 52)
                    } else {
                        Text("Continue")
                            .font(Font.custom("Poppins", size: 18).weight(.semibold))
                            .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                            .frame(width: 315, height: 52)
                            .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .inset(by: 1.50)
                                    .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.50)
                            )
                    }
                }
                .disabled(isLoading || email.isEmpty)
                
                // Back to Sign In Button
                Button(action: {
                    navigationManager.currentScreen = .signIn
                }) {
                    Text("Back to Sign in")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color.white)
                }
                .padding(.top, 10)
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
        .navigationBarBackButtonHidden(true)
        .fullScreenCover(isPresented: .constant(navigationManager.currentScreen == .forgotPasswordOTP)) {
            ForgetPassOTPUIView(navigationManager: navigationManager, email: email)
                                }
    }
    
    // Function to send password reset code to the backend
    private func sendPasswordResetCode() {
        // Validate email
        guard !email.isEmpty, isValidEmail(email) else {
            errorMessage = "Please enter a valid email."
            return
        }
        
        // Start loading
        isLoading = true
        errorMessage = nil
        
        // Perform network request to send password reset code
        Task {
            do {
                let url = URL(string: "\(baseURL)/auth/forget-password")!
                var request = URLRequest(url: url)
                request.httpMethod = "POST"
                request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                
                let body: [String: String] = ["email": email]
                request.httpBody = try JSONSerialization.data(withJSONObject: body)
                
                let (data, response) = try await URLSession.shared.data(for: request)
                
                // Check response
                if let httpResponse = response as? HTTPURLResponse {
                    switch httpResponse.statusCode {
                    case 200, 201:
                        // Successfully sent reset code
                        DispatchQueue.main.async {
                            isLoading = false
                            // Navigate to OTP verification screen
                            navigationManager.currentScreen = .forgotPasswordOTP
                        }
                    default:
                        // Handle error response
                        let errorData = String(data: data, encoding: .utf8)
                        throw NSError(domain: "PasswordResetError", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: errorData ?? "Unknown error"])
                    }
                }
            } catch {
                // Handle network or parsing errors
                DispatchQueue.main.async {
                    isLoading = false
                    errorMessage = error.localizedDescription
                }
            }
                
        }
        
    }
    
    // Helper function for email validation
    private func isValidEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
}

struct ForgetPassUIView_Previews: PreviewProvider {
    static var previews: some View {
        ForgetPassUIView(navigationManager: NavigationStateManager())
    }
}
