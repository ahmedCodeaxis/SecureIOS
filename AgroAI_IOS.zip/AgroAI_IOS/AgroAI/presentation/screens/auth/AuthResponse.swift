import Foundation

struct AuthResponse: Codable {
    let token: String
}
