import SwiftUI

struct SignUpUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @StateObject private var viewModel = EditProfileViewModel()

    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var isAuthenticated = false
    @State private var errorMessage: String? = nil
    @State private var isOTPScreenPresented: Bool = false  // Boolean flag to control OTP screen
    let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"

    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                HStack {
                    Spacer()
                    Image("ic_sign_up_logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 286.1, height: 75.55)
                        .padding(.trailing, -90)
                        .padding(.top, -60)
                }
                
                VStack(alignment: .leading, spacing: 0) {
                    Text("Make your")
                        .font(Font.custom("Poppins", size: 24).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    Text("account")
                        .font(Font.custom("Poppins", size: 40).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                }
                .padding(.trailing, 90)
                .padding(.top, -90)
                
                // Input Fields
                inputField(imageName: "ic_profile", placeholder: "Full name", text: $name)
                inputField(imageName: "ic_email", placeholder: "Email", text: $email)
                inputField(imageName: "ic_password", placeholder: "Password", text: $password, isSecure: true)
                
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .font(.footnote)
                        .padding(.top, 10)
                }
                
                Button(action: {
                    Task {
                        await signUp()
                    }
                }) {
                    Text("Register")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93, opacity: 0.93))
                        .frame(width: 315, height: 52)
                        .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.5)
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93, opacity: 0.93), lineWidth: 1.5)
                        )
                }
                
                Button(action: {
                    navigationManager.currentScreen = .signIn
                }) {
                    Text("Sign in")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        //.foregroundColor(Color(red: 0.93, 0.93, 0.93))
                }
                .padding(.top, 10)
            }
            .padding(.horizontal, 20)
        }
        // Full screen cover to show the OTP screen based on the boolean flag
        .fullScreenCover(isPresented: $isOTPScreenPresented) {
            SignUpOTPUIView(navigationManager: navigationManager, email: email)
                .onDisappear {
                    // Reset flag when OTP screen is dismissed
                    isOTPScreenPresented = false
                }
        }
    }
    
    private func inputField(imageName: String, placeholder: String, text: Binding<String>, isSecure: Bool = false) -> some View {
        Group {
            HStack {
                Image(imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20, height: 20)
                
                if isSecure {
                    SecureField(placeholder, text: text)
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                        .padding()
                        .background(Color(red: 0.84, green: 0.89, blue: 0.89))
                        .cornerRadius(8)
                } else {
                    TextField(placeholder, text: text)
                        .font(Font.custom("Poppins", size: 14).weight(.medium))
                        .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                        .padding()
                        .background(Color(red: 0.84, green: 0.89, blue: 0.89))
                        .cornerRadius(8)
                }
            }
            .frame(width: 315, height: 52)
        }
    }
    
    private func signUp() async {
        guard !name.isEmpty, !email.isEmpty, !password.isEmpty else {
            DispatchQueue.main.async {
                errorMessage = "Please fill in all fields."
            }
            return
        }
        
        let signUpUrl = URL(string: "\(baseURL)/user/signup")!
        var request = URLRequest(url: signUpUrl)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body = [
            "name": name,
            "email": email,
            "password": password
        ]
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)
            request.httpBody = jsonData
            let (data, response) = try await URLSession.shared.data(for: request)
            
            if let httpResponse = response as? HTTPURLResponse,
               (httpResponse.statusCode == 200 || httpResponse.statusCode == 201) {
                DispatchQueue.main.async {
                    // Successfully registered, show OTP screen
                    isOTPScreenPresented = true
                    errorMessage = nil
                }
                print("Well done - Registration successful!")
            } else {
                DispatchQueue.main.async {
                    errorMessage = "Registration failed. Please try again."
                }
            }
        } catch {
            DispatchQueue.main.async {
                errorMessage = "An error occurred: \(error.localizedDescription)"
            }
        }
    }
}

struct SignUpUIView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpUIView(navigationManager: NavigationStateManager())
    }
}
