import SwiftUI

struct SignUpOTPUIView: View {
    @ObservedObject var navigationManager: NavigationStateManager
    @State private var otpFields: [String] = Array(repeating: "", count: 4)  // 4 OTP fields
    @State private var otpcode: String = "" // Combined OTP code
    @State private var isVerified = false // Variable to track verification status
    @State private var errorMessage: String? = nil // Error message for failed verificatio  n
    
    let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"
    //email ili jey mil signup
    var email: String
    // Focus state to manage which OTP field is focused
    @FocusState private var focusedField: Int?

    var body: some View {
        ZStack {
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // Logo
                Image("ic_email_submit_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 170, height: 157)
                    .padding(.top, 50)
                
                // Title
                Text("Validate your email")
                    .font(.system(size: 24, weight: .bold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                Text("Enter the verification code we just sent to your email")
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                    .padding(.bottom, 20)
                
                // OTP Fields
                HStack(spacing: 20) {
                    ForEach(0..<4, id: \.self) { index in
                        TextField("", text: $otpFields[index])
                            .font(.system(size: 24, weight: .bold))
                            .frame(width: 60, height: 60)
                            .background(Color(red: 0.84, green: 0.89, blue: 0.89))
                            .cornerRadius(12)
                            .multilineTextAlignment(.center)
                            .keyboardType(.numberPad)
                            .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
                            .overlay(
                                RoundedRectangle(cornerRadius: 12)
                                    .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 2)
                            )
                            .focused($focusedField, equals: index) // Bind focus state
                            .onChange(of: otpFields[index]) { newValue in
                                // Allow only one character per field
                                if newValue.count > 1 {
                                    otpFields[index] = String(newValue.prefix(1))
                                }
                                // Move to next field if a digit is entered
                                if newValue.count == 1 && index < 3 {
                                    focusedField = index + 1
                                }
                                // Move to previous field if backspace is pressed
                                if newValue.isEmpty && index > 0 {
                                    focusedField = index - 1
                                }
                            }
                    }
                }
                .padding(.vertical, 30)
                
                // Timer Text
                Text("Code expires in: 15:00")
                    .font(Font.custom("Poppins", size: 14).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                // Resend Code Button
                Button(action: {
                    print("Resend code tapped")
                }) {
                    Text("Resend Code")
                        .font(.system(size: 14, weight: .semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .underline()
                }
                .padding(.top, 10)
                
                // Verify Button
                Button(action: {
                    otpcode = otpFields.joined() // Combine OTP fields
                    verifyOTP() // Send OTP to API for verification
                }) {
                    Text("Verify")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .frame(width: 315, height: 52)
                        .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.50)
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.50)
                        )
                }
                .padding(.top, 30)
                
                // Display error message if OTP verification fails
                if let errorMessage = errorMessage {
                    Text(errorMessage)
                        .font(.system(size: 14))
                        .foregroundColor(.red)
                        .padding(.top, 10)
                }
                
                Spacer()
            }
            .padding(.horizontal, 20)
        }
    }
    
    // Function to send the OTP and email to the server for verification
    private func verifyOTP() {
        guard let url = URL(string: "\(baseURL)/user/verify-otp") else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Use the passed email
                let parameters: [String: Any] = [
                    "email": email, // Use the passed email
                    "otpCode": otpcode // Combined OTP code
                ]
                
        
        do {
            // Convert parameters to JSON
            let jsonData = try JSONSerialization.data(withJSONObject: parameters, options: [])
            request.httpBody = jsonData
        } catch {
            print("Error serializing JSON: \(error)")
            return
        }
        
        // Send the request
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.errorMessage = "Error during request: \(error.localizedDescription)"
                }
                return
            }
            
            if let data = data {
                // Process server response
                if let responseString = String(data: data, encoding: .utf8) {
                    if responseString.contains("success") {
                        DispatchQueue.main.async {
                            self.isVerified = true
                            self.errorMessage = nil
                            
                            navigationManager.currentScreen = .signIn

                            
                            
                            
                            
                            
                        }
                    } else {
                        DispatchQueue.main.async {
                            self.errorMessage = "Invalid OTP. Please try again."
                        }
                    }
                }
            }
        }
        
        task.resume() // Start the network request
    }
}

struct SignUpOTPUIView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpOTPUIView(navigationManager: NavigationStateManager(), email: "test@example.com"  )
    }
}
