struct UserCredentials {
    let email: String
    let password: String
}
