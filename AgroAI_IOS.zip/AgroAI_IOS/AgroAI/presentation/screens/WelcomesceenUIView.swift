import SwiftUI

struct Welcomesceen: View {
    @ObservedObject var navigationManager: NavigationStateManager
    
    var body: some View {
        ZStack {
            // Background Color
            Color(red: 0.29, green: 0.68, blue: 0.47)
                .edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 20) {
                // Logo Image
                Image("ic_email_submit_logo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 170, height: 157)
                    .padding(.top, 50)
                
                // Welcome Text
                Text("Welcome Back")
                    .font(Font.custom("Poppins", size: 32).weight(.semibold))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                
                Text("You can sign in again with your account or make a newer one")
                    .font(Font.custom("Poppins", size: 19).weight(.medium))
                    .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 20)
                
                // User Name Display
//                Button(action: {
//                    print("User name button tapped")
//                }) {
//                    Text("IHEB BEN DHAOU")
//                        .font(Font.custom("Poppins", size: 14).weight(.medium))
//                        .foregroundColor(Color(red: 0.23, green: 0.25, blue: 0.28))
//                        .frame(width: 315, height: 52)
//                        .background(Color(red: 0.84, green: 0.89, blue: 0.89))
//                        .cornerRadius(8)
//                }
//                
                // Sign In Button
                Button(action: {
                    navigationManager.currentScreen = .signIn
                }) {
                    Text("Sign in")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .frame(width: 315, height: 52)
                        .background(Color(red: 0.29, green: 0.68, blue: 0.47))
                        .cornerRadius(8)
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .inset(by: 1.5)
                                .stroke(Color(red: 0.93, green: 0.93, blue: 0.93), lineWidth: 1.5)
                        )
                }
                
                // Register Button
                Button(action: {
                    navigationManager.currentScreen = .signUp
                }) {
                    Text("Register")
                        .font(Font.custom("Poppins", size: 18).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .frame(width: 315, height: 52)
                        .background(Color.clear)
                }
            }
            .padding(.top, 100)
        }
        // Add these fullScreenCover modifiers outside the ZStack
        .fullScreenCover(isPresented: Binding(
            get: { navigationManager.currentScreen == .signIn },
            set: { _ in }
        )) {
            SignInUIView(navigationManager: navigationManager)
        }
        .fullScreenCover(isPresented: Binding(
            get: { navigationManager.currentScreen == .signUp },
            set: { _ in }
        )) {
            SignUpUIView(navigationManager: navigationManager)
        }
    }
}

struct Welcomesceen_Previews: PreviewProvider {
    static var previews: some View {
        Welcomesceen(navigationManager: NavigationStateManager())
    }
}
