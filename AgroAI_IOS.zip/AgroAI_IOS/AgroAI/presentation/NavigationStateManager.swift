import SwiftUI

enum NavigationState {
    case splash
    case welcome
    case signIn
    case signUp
    case forgotPassword
    case forgotPasswordOTP
    case signInOTP
    case SignUpOTP
    case resetPassword
    case profile
    case editprofile
    case changePassword

}

class NavigationStateManager: ObservableObject {
    @Published var currentScreen: NavigationState = .splash
    @Published var token: String? // Add a property to hold the token
    @Published var navigateToProfile = false // A new property to control navigation to ProfileUIView

    func logout() {
        token = nil
        currentScreen = .signIn
    }

    func navigateToEditProfile() {
            currentScreen = .editprofile // This triggers navigation to EditProfileUIView
        }
    
    
    func navigateToOTPsignup(){
        
        currentScreen = .signInOTP
        
    }
    
    
}
