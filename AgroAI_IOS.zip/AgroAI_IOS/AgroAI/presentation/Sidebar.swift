//
//  Sidebar.swift
//  AgroAI
//
//  Created by Apple Esprit on 14/11/2024.
//

import SwiftUI

struct Sidebar: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct Sidebar_Previews: PreviewProvider {
    static var previews: some View {
        Sidebar()
    }
}
