import SwiftUI
import CoreData

struct Splashscreen: View {
    @StateObject private var navigationManager = NavigationStateManager()
    
    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                ZStack {
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: 132.50, height: 148)
                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 133, height: 148)
                        .offset(x: 0, y: -18)
                    Text("AgroAI")
                        .font(Font.custom("Poppins", size: 24).weight(.semibold))
                        .foregroundColor(Color(red: 0.93, green: 0.93, blue: 0.93))
                        .offset(x: -0.75, y: 74)
                }
                .frame(maxWidth: .infinity, minHeight: 184, maxHeight: 184)
            }
            .padding(
                EdgeInsets(top: 322, leading: 131, bottom: 346, trailing: 129.50)
            )
            .frame(width: 393, height: 852)
            .background(Color(red: 0.29, green: 0.68, blue: 0.47))
            .onAppear {
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                    withAnimation {
                        navigationManager.currentScreen = .welcome
                    }
                }
            }
            .fullScreenCover(isPresented: Binding(
                get: { navigationManager.currentScreen != .splash },
                set: { _ in }
            )) {
                Welcomesceen(navigationManager: navigationManager) // Pass the navigationManager here
            }
        }
    }
}

struct Splashscreen_Previews: PreviewProvider {
    static var previews: some View {
        Splashscreen()
    }
}
