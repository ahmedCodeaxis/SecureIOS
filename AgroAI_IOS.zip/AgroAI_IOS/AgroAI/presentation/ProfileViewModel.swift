import SwiftUI
import SwiftKeychainWrapper
import Combine

class AuthViewModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var isAuthenticated: Bool = false
    @Published var errorMessage: String?
    
    func signIn(completion: @escaping (String?) -> Void) {
        guard !email.isEmpty, !password.isEmpty else {
            errorMessage = "Email and password cannot be empty."
            completion(nil)
            return
        }
        
        let credentials = UserCredentials(email: email, password: password)
        
        authenticateUser(credentials: credentials) { result in
            switch result {
            case .success(let authResponse):
                KeychainWrapper.standard.set(authResponse.token, forKey: "authToken")
                self.isAuthenticated = true
                completion(authResponse.token)
            case .failure(let error):
                self.errorMessage = error.localizedDescription
                completion(nil)
            }
        }
    }
    
    private func authenticateUser(credentials: UserCredentials, completion: @escaping (Result<AuthResponse, Error>) -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            if credentials.email == "test@example.com" && credentials.password == "password" {
                completion(.success(AuthResponse(token: "fake-jwt-token")))
            } else {
                completion(.failure(NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "Invalid credentials"])))
            }
        }
    }
}
