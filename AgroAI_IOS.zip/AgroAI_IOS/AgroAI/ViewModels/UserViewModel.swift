import Foundation
import SwiftUI
import Combine

class UserViewModel: ObservableObject {
    @Published var user: User?
    
    func fetchUser() {
        // Simulate fetching user data
        self.user = User(id: UUID(), name: "John Doe", email: "john@example.com", password: "000000")
    }
}

