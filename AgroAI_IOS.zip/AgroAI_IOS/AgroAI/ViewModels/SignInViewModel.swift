import Foundation
import SwiftUI
import Combine
import SwiftKeychainWrapper

class SignInViewModel: ObservableObject {
    @Published var email: String = ""
    @Published var password: String = ""
    @Published var errorMessage: String?
    @Published var isLoading: Bool = false
    @Published var showProfile: Bool = false

    let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"

    func signIn() async {
        guard !email.isEmpty, !password.isEmpty else {
            DispatchQueue.main.async { // Ensure this runs on the main thread
                self.errorMessage = "Please fill in all fields."
            }
            return
        }

        DispatchQueue.main.async { // Ensure this runs on the main thread
            self.isLoading = true
        }

        let signInUrl = URL(string: "\(baseURL)/auth/sign-in")!
        var request = URLRequest(url: signInUrl)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = ["email": email, "password": password]

        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)
            request.httpBody = jsonData
            
            let (data, response) = try await URLSession.shared.data(for: request)

            if let httpResponse = response as? HTTPURLResponse,
               (httpResponse.statusCode == 200 || httpResponse.statusCode == 201) {
                if let jsonResult = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
                   let token = jsonResult["token"] as? String {
                    // Store the token securely in Keychain
                    KeychainWrapper.standard.set(token, forKey: "authToken")
                    
                    DispatchQueue.main.async { // Ensure this runs on the main thread
                        self.showProfile = true // Trigger navigation to ProfileUIView
                        self.errorMessage = nil // Clear any previous error message
                    }
                } else {
                    DispatchQueue.main.async { // Ensure this runs on the main thread
                        self.errorMessage = "Failed to extract token from response."
                    }
                }
            } else {
                DispatchQueue.main.async { // Ensure this runs on the main thread
                    self.errorMessage = "Sign in failed. Please try again."
                }
            }
        } catch {
            DispatchQueue.main.async { // Ensure this runs on the main thread
                self.errorMessage = "An error occurred. Please try again."
            }
        }

        DispatchQueue.main.async { // Ensure this runs on the main thread
            self.isLoading = false // End loading state
        }
    }
}
