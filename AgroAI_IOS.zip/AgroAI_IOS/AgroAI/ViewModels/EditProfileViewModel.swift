import Foundation
import SwiftUI
import JWTDecode
import SwiftKeychainWrapper

class EditProfileViewModel: ObservableObject {
    @Published var fullName: String = ""
    @Published var email: String = ""
    @Published var errorMessage: String? = nil
    @Published var showProfile: Bool = false
    @Published var userId: String = "" // Store user ID here
    @Published var isLoading: Bool = false

    let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"

    func loadUserData() {
        // Retrieve user data from Keychain (if available)
        if let savedFullName = KeychainWrapper.standard.string(forKey: "userFullName") {
            fullName = savedFullName
        }

        if let savedEmail = KeychainWrapper.standard.string(forKey: "userEmail") {
            email = savedEmail
        }

        // Load data from token if necessary
        if let token = KeychainWrapper.standard.string(forKey: "authToken") {
            loadUserDataFromToken(token: token)
        }
    }

    private func loadUserDataFromToken(token: String) {
        let components = token.components(separatedBy: ".")
        guard components.count > 1 else { return }

        let claimsPart = components[1]
        let paddedClaimsPart = addBase64Padding(to: claimsPart)
        let base64EncodedString = paddedClaimsPart.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        
        guard let data = Data(base64Encoded: base64EncodedString) else { return }
        
        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                DispatchQueue.main.async { // Ensure this runs on the main thread
                    self.fullName = json["name"] as? String ?? "No Name"
                    self.email = json["email"] as? String ?? "No Email"
                    self.userId = json["id"] as? String ?? "" // Save user ID
                }
            }
        } catch {
            print("Error decoding token: \(error)")
        }
    }

    private func addBase64Padding(to string: String) -> String {
        let length = string.count
        let paddedLength = length + (4 - length % 4) % 4
        let padding = String(repeating: "=", count: paddedLength - length)
        return string + padding
    }

    func updateProfile() async {
        guard !fullName.isEmpty, !email.isEmpty else {
            DispatchQueue.main.async { // Ensure this runs on the main thread
                self.errorMessage = "Please fill in all fields."
            }
            return
        }

        guard !userId.isEmpty else {
            DispatchQueue.main.async { // Ensure this runs on the main thread
                self.errorMessage = "User ID is missing."
            }
            return
        }

        isLoading = true // Start loading state

        // URL for the profile update endpoint
        let updateProfileUrl = URL(string: "\(baseURL)/user/update/\(userId)")!
        var request = URLRequest(url: updateProfileUrl)
        request.httpMethod = "PATCH" // Use PATCH for partial update
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // Construct the request body with updated user data
        let body: [String: Any] = [
            "name": fullName,
            "email": email
        ]
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)
            request.httpBody = jsonData
            
            // Perform the network request to update the profile
            let (data, response) = try await URLSession.shared.data(for: request)
            
            if let httpResponse = response as? HTTPURLResponse,
               (httpResponse.statusCode == 200 || httpResponse.statusCode == 201) {
                if let jsonResult = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    DispatchQueue.main.async { // Ensure this runs on the main thread
                        if let updatedFullName = jsonResult["fullName"] as? String {
                            KeychainWrapper.standard.set(updatedFullName, forKey: "userFullName")
                        }
                        if let updatedEmail = jsonResult["email"] as? String {
                            KeychainWrapper.standard.set(updatedEmail, forKey: "userEmail")
                        }
                        
                        self.showProfile = true // Navigate back to Profile screen
                        self.errorMessage = nil // Clear any previous error message
                    }
                } else {
                    DispatchQueue.main.async { // Ensure this runs on the main thread
                        self.errorMessage = "Failed to parse the response from the server."
                    }
                }
            } else {
                DispatchQueue.main.async { // Ensure this runs on the main thread
                    self.errorMessage = "Profile update failed. Please try again."
                }
            }
        } catch {
            DispatchQueue.main.async { // Ensure this runs on the main thread
                self.errorMessage = "An error occurred. Please try again."
            }
        }

        isLoading = false // End loading state
    }
}
