import Foundation
import SwiftKeychainWrapper
import JWTDecode
import SwiftUI

class ChangePassViewModel: ObservableObject {
    @Published var currentPassword: String = ""
    @Published var newPassword: String = ""
    @Published var confirmPassword: String = ""
    @Published var isCurrentPasswordVisible: Bool = false
    @Published var isNewPasswordVisible: Bool = false
    @Published var isConfirmPasswordVisible: Bool = false
    @Published var errorMessage: String? = nil
    @Published var showProfile = false
    @Published var fullName: String = ""
    @Published var email: String = ""
    @Published var userId: String = "" // Store user ID here
    @Published var password: String = ""
    
    private var user: User?
    private let baseURL = "https://ce2c-197-3-6-252.ngrok-free.app/api/v1"
    
    // Load user data from Keychain
    func loadUserData() {
        // Retrieve user data from Keychain (if available)
        if let savedFullName = KeychainWrapper.standard.string(forKey: "password") {
            password = savedFullName
        }
        
        if let savedEmail = KeychainWrapper.standard.string(forKey: "userEmail") {
            email = savedEmail
        }

        // Optionally, load data from token if necessary
        if let token = KeychainWrapper.standard.string(forKey: "authToken") {
            loadUserDataFromToken(token: token)
        }
    }
    
    private func loadUserDataFromToken(token: String) {
        let components = token.components(separatedBy: ".")
        guard components.count > 1 else { return }

        let claimsPart = components[1]
        let paddedClaimsPart = addBase64Padding(to: claimsPart)
        let base64EncodedString = paddedClaimsPart.replacingOccurrences(of: "-", with: "+").replacingOccurrences(of: "_", with: "/")
        
        guard let data = Data(base64Encoded: base64EncodedString) else { return }
        
        do {
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                DispatchQueue.main.async {
                    // Extract and set the user data
                    self.password = json["password"] as? String ?? "No password"
                    self.email = json["email"] as? String ?? "No Email"
                    self.userId = json["id"] as? String ?? "" // Save user ID
                }
            }
        } catch {
            print("Error decoding token: \(error)")
        }
    }

    // Update Profile: Change password
    func updatePassword() async {
        // Check if userId is available
        guard !userId.isEmpty else {
            errorMessage = "User ID is missing."
            return
        }
        
        // Check if all required fields are filled
        guard !currentPassword.isEmpty, !newPassword.isEmpty else {
            errorMessage = "Please fill in all fields."
            return
        }
        
        // Ensure passwords match
        if newPassword != confirmPassword {
            errorMessage = "New password and confirm password do not match."
            return
        }
        
        // Proceed with updating password
        let updateProfileUrl = URL(string: "\(baseURL)/user/update-password/\(userId)")!
        var request = URLRequest(url: updateProfileUrl)
        request.httpMethod = "PATCH"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: Any] = [
            "oldPassword": currentPassword,
            "newPassword": newPassword
        ]
        
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: body)
            request.httpBody = jsonData
            
            let (data, response) = try await URLSession.shared.data(for: request)
            
            if let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 {
                showProfile = true // Password updated, navigate to profile
                errorMessage = nil
            } else {
                errorMessage = "Profile update failed. Please try again."
            }
        } catch {
            errorMessage = "An error occurred. Please try again."
        }
    }
    
    // Helper function to add padding to base64 strings
    private func addBase64Padding(to string: String) -> String {
        let length = string.count
        let paddedLength = length + (4 - length % 4) % 4
        let padding = String(repeating: "=", count: paddedLength - length)
        return string + padding
    }
}
