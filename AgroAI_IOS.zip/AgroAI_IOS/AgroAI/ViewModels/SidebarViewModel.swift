//
//  SidebarViewModel.swift
//  AgroAI
//
//  Created by Apple Esprit on 14/11/2024.
//

import Foundation
import SwiftUI
import Combine

class SidebarViewModel: ObservableObject {
    @Published var menuItems: [MenuItem] = [
        MenuItem(title: "Home"),
        MenuItem(title: "Messages"),
        MenuItem(title: "Topics"),
        MenuItem(title: "Bookmarks"),
        MenuItem(title: "Profile"),
        MenuItem(title: "Notifications"),
        MenuItem(title: "AR")
    ]
    var navigationStateManager: NavigationStateManager?
    
    init(navigationStateManager: NavigationStateManager?) {
        self.navigationStateManager = navigationStateManager
        
        // Add any additional logic here if needed
    }
}
